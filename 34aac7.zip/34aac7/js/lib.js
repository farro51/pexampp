$(function() {
    $('#imi_content_menu div').mouseover(function(){
        $(this).addClass('imi_menu_over');
    });
    $('#imi_content_menu div').mouseout(function(){
        $(this).removeClass('imi_menu_over');
    });
    $('#imi_form_register').dialog({  title: "Register",
                                   autoOpen: false,
                                   height: 380,
                                   width: 550,
                                   modal: true,
                                   buttons: { "send": function() { imi.clean_register(); var flag = imi.valida_form_register(); if(!flag){imi.new_user();} },
                                           "cancel": function() { $(this).dialog("close"); } } });
                                           
    $('#imi_form_project').dialog({  title: "Projects",
                                   autoOpen: false,
                                   height: 380,
                                   width: 400,
                                   modal: true,
                                   buttons: { "send": function() { imi.clean_project(); var flag = imi.valida_form_project(); if(!flag){imi.insert_project();} },
                                           "cancel": function() { $(this).dialog("close"); } } });
    $('#imi_update_segment').dialog({  title: "Segments",
                                   autoOpen: false,
                                   height: 280,
                                   width: 300,
                                   modal: true,
                                   buttons: { "send": function() { imi.update_segment(); },
                                           "cancel": function() { $(this).dialog("close"); } } });                                            
                                           
    $('#imi_messages').dialog({  title: "Information",
                                   autoOpen: false,
                                   height: 380,
                                   width: 550,
                                   modal: true,
                                   buttons: { "ok": function() { $(this).dialog("close"); } } });
    $('#imi_confirmation_delete_project').dialog({  title: "Confirmation",
                                   autoOpen: false,
                                   height: 250,
                                   width: 300,
                                   modal: true,
                                   buttons: { "ok": function() { imi.delete_project(imi.current_selected_project);  $(this).dialog("close");},
                                           "cancel": function() { $(this).dialog("close"); } }});
    imi.getuser();
});

var imi = { 
    roles : { guest: 'guest', participant: 'participant', coordinator: 'coordinator', admin : 'admin'},
    message_types : { information : 1, error: 2},
    rest_uri : 'http://localhost/34aac7/resources/index.php/',
    sections : {home: 1, projects: 2, traffic: 3},
    timer : {value: 0}
    };

imi.current_rol = imi.roles.guest;
imi.current_section = imi.sections.home;
imi.current_selected_project = 0;
imi.current_selected_segment = 0;

/****************** PROJECTS FUNCTIONS ************************/

imi.insert_project = function(){
    imi.loading(true);
    var data_params = {};
    data_params.title = $('#project_title').val();
    data_params.description = $('#project_description').val();
    $.ajax({
        url: imi.rest_uri + 'projects.json',
        data: data_params,
        type: 'POST',
        success : function(data) {
            imi.loading(false);
            if(data.id){
                $('#imi_content_project_list .notfound').hide();
                data_params.id = data.id;
                $('#imi_form_project').dialog('close');
                $('#imi_content_project_list').append(tpl_project_project(data_params));
            }
            else if(data.response){
                imi.print_message(data.response, imi.message_types.error);
            }
            else{
                imi.print_message(data, imi.message_types.error);
            }
        }
    });
}

imi.open_form_project = function() {
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    $('#project_coordinate_x').val('');
    $('#project_coordinate_y').val('');
    $('#project_description').val('');
    $('#imi_form_project').dialog('open');
};

imi.get_projects = function () {
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    imi.current_section = imi.sections.projects;
    if(imi.current_rol == imi.roles.guest){
        $('#imi_form_login').html(tpl_form_login);
        $('#imi_content_content').html(tpl_project_insert(false));
    }
	else if(imi.current_rol != imi.roles.coordinator){
		$('#imi_content_content').html(tpl_project_insert(false));
	}
    else{
        $('#imi_content_content').html(tpl_project_insert(true));
    }    
    var data_parameters = {};
    data_parameters.role = imi.current_rol;
    $.ajax({
        url: imi.rest_uri + 'projects.json',
        type: 'GET',
        success : function(data) {
            imi.load_projects(data);
        },
        statusCode : {
            404 : function(){$('#imi_content_project_list').html('<span class="notfound">Projects Not Found</span>');},
            501: function(){$('#imi_content_project_list').text('<span class="notfound">Server Error</span>');}
        }
    });
};

imi.load_projects = function (data){
    var project_obj;
    for(key in data) {
        project_obj = data[key];
        $('#imi_content_project_list').append(tpl_project_project(project_obj));
    }
}

imi.load_project_description = function (id) {
    imi.print_message($('#imi_static_block_project_'+id+' .imi_project_description').text());
}

imi.delete_project = function (id) {
    imi.loading(true);
    $.ajax({
        url: imi.rest_uri + 'projects/'+id+'.json',
        type: 'DELETE',
        success : function(data) {
            if(data.response && data.response == true){
                $('#imi_static_block_project_'+id).remove();
                imi.print_message('Project deleted');
            }
            else if(data.response){
                imi.print_message(data.response, imi.message_types.error);
            }
            else{
                imi.print_message('The project could not be deleted ', imi.message_types.error);
            }
            imi.loading(false);
        }
    });
}

imi.delete_project_confirm = function (id) {
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    imi.current_selected_project = id;
    $('#imi_confirmation_delete_project').dialog('open');
}

imi.open_description_project = function(path) {
	window.location= 'file://'+path;
}

/************************* TRAFFIC FUNCTIONS *******************************/

imi.get_segments = function(){
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    if(imi.current_rol == imi.roles.guest){
        $('#imi_form_login').html(tpl_form_login);
    }
    imi.current_section = imi.sections.traffic;
    $('#imi_content_content').html(tpl_segment_section);
    var data_parameters = {};
    data_parameters.action = 'all';
    $.ajax({
        url: imi.rest_uri + 'segments.json',
        data: data_parameters,
        type: 'GET',
        success : function(data) {
            if(data.response){
                imi.print_message(data.response);
            }
            else{
                imi.load_segments(data);
            }
        },
        statusCode : {
            404 : function(){$('#imi_content_project_list').html('<span class="notfound">Segments Not Found</span>');},
            501: function(){$('#imi_content_project_list').text('<span class="notfound">Server Error</span>');}
        }
    });
    
}

imi.update_segment = function(){
    
    imi.loading(true);
    var data_params = {};
    data_params.intensity = $('#segment_intensity').val();
    data_params.update = true;
    $.ajax({
        url: imi.rest_uri + 'segments/'+imi.current_selected_segment+'.json',
        data: data_params,
        type: 'PUT',
        success : function(data) {
            if(data.response && data.response == true){
                //imi.change_intensity
                imi.print_message('Intensity updated');
                $('.imi_segment_intesity #imi_segment_intensity_'+imi.current_selected_segment).text(data_params.intensity);
            }
            else if(data.response){
                imi.print_message(data.response, imi.message_types.error);
            }
            else{
                imi.print_message('The segment could not be update ', imi.message_types.error);
            }
            $('#imi_update_segment').dialog('close');
            imi.loading(false);
        }
    });
}

imi.search = function(){
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    $('#imi_projects_box').html(tpl_project_insert(false));
    $('#imi_segments_box').html(tpl_segment_section);
    var data_parameters = {};
    data_parameters.x = $('#traffic_form_x').val();
    data_parameters.y = $('#traffic_form_y').val();
    data_parameters.limit = $('#traffic_form_limit').val();
    data_parameters.action = 'search';
    $.ajax({
        url: imi.rest_uri + 'projects.json',
        data: data_parameters,
        type: 'GET',
        success : function(data) {
            if(data.response){
                imi.print_message(data.response);
            }
            else{
                imi.load_projects(data);
            }
        },
        statusCode : {
            404 : function(){$('#imi_content_project_list').html('<span class="notfound">Projects Not Found</span>');},
            501: function(){$('#imi_content_project_list').text('<span class="notfound">Server Error</span>');}
        }
    });
    
    $.ajax({
        url: imi.rest_uri + 'segments.json',
        data: data_parameters,
        type: 'GET',
        success : function(data) {
            if(data.response){
                imi.print_message(data.response);
            }
            else{
                imi.load_segments(data);
            }
        },
        statusCode : {
            404 : function(){$('#imi_content_segments_list').html('<span class="notfound">Projects Not Found</span>');},
            501: function(){$('#imi_content_segments_list').html('<span class="notfound">Server Error</span>');}
        }
    });
    
}

imi.update_intensity = function (id) {
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    imi.current_selected_segment = id;
    $('#segment_intensity').val('');
    $('#imi_update_segment').dialog('open');
}

imi.load_segments = function (data){
    var segment_obj;
    for(key in data) {
        segment_obj = data[key];
        $('#imi_content_segments_list').append(tpl_traffic_segment(segment_obj));
    }
}

imi.load_traffic = function (){
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    if(imi.current_rol == imi.roles.guest){
        $('#imi_form_login').html(tpl_form_login);
    }
    imi.current_section = imi.sections.traffic;
    $('#imi_content_content').html(tpl_traffic_section);
}


/****************** USER FUNCTIONS *******************************************/

imi.open_form_register = function() {
    $('#register_firstname').val('');
    $('#register_lastname').val('');
    $('#register_email').val('');
    $('#register_role').val('');
    $('#register_password').val('');
    $('#register_repeat_password').val('');
    $('#imi_form_register').dialog('open');
};

imi.new_user = function () {
    imi.loading(true);
    var password = $('#register_password').val();
    var repeat_password = $('#register_repeat_password').val();
    if(password != repeat_password){
        imi.print_message('The passwords do not match');
    }
    else{
        var data_params = {};
        data_params.name = $('#register_firstname').val();
        data_params.lastname = $('#register_lastname').val();
        data_params.email = $('#register_email').val();
        data_params.role = $('#register_role').val();
        data_params.password = calcMD5($('#register_password').val());
        $.ajax({
            url: imi.rest_uri + 'users.json',
            data: data_params,
            type: 'POST',
            success : function(data) {
                imi.loading(false);
                if(data.id){
                    $('#imi_form_register').dialog('close');
                    imi.print_message('The user was registered successful');
                }
                else if(data.response){
                    imi.print_message(data.response, imi.message_types.error);
                }
                else{
                    imi.print_message(data, imi.message_types.error);
                }
            }
        });
    }
};

imi.getuser = function(){
    $.ajax({
        url: imi.rest_uri + 'actions/currentuser.json',
        type: 'POST',
        success : function(data) {
            if(data.successful){
                imi.current_rol = data.entity.rol;
                var html = 'You are authenticated as <i>'+data.entity.fullname + '</i> ';
                html += '<a href="javascript:;" onclick="imi.logout()" class="ui-button-text imi_login">(logout)</a>';
                $('#imi_form_login').html(html);
            }
            else{
                imi.current_rol = imi.roles.guest;
                imi.load_home();
            }
            imi.change_auth();
        }
    });
}


/******************** OTHERS FUNCTIONS *******************************/

imi.change_auth = function(){
    $('.imi_traffic_edition_button').hide();
    switch(imi.current_rol){
    case imi.roles.guest:
    case imi.roles.participant:
        $('.imi_seg_users').show();
        $('.imi_seg_coordinator').hide();
		$('.imi_seg_admin').hide();
        break;
    case imi.roles.admin:
		$('.imi_seg_admin').show();
	case imi.roles.coordinator:
        $('.imi_seg_users').show();
        $('.imi_seg_coordinator').show();
        break;
    }  
};

imi.authentication = function(){
    var data_params = {};
    data_params.username = $('#login_username').val();
    var login_password = calcMD5($('#login_password').val());
    data_params.password = login_password;
    $.ajax({
        url: imi.rest_uri + 'actions/login.json',
        data: data_params,
        type: 'POST',
        success : function(data) {
            if(data.successful){
                imi.timer.value = setTimeout('imi.logout()', 600*1000);
                imi.current_rol = data.entity.rol;
                imi.change_auth();
                var html = 'You are authenticated as <i>'+data.entity.fullname + '</i> ';
                html += '<a href="javascript:;" onclick="imi.logout()" class="ui-button-text imi_login">(logout)</a>';
                $('#imi_form_login').html(html);
                imi.load_home();
            }
            else if(data.response){
                imi.print_message(data.response, imi.message_types.error);
            }
            else{
                imi.print_message(data, imi.message_types.error);
            }
        }
    });
}

imi.logout = function(){
    $.ajax({
        url: imi.rest_uri + 'actions/logout.json',
        type: 'POST',
        success : function(data) {
            if(data.successful){
                imi.current_rol = imi.roles.guest;
                imi.change_auth();
                imi.load_home();
            }
            else if(data.response){
                imi.print_message(data.response, imi.message_types.error);
            }
            else{
                imi.print_message(data, imi.message_types.error);
            }
        }
    });
}

imi.print_message = function (text, type) {
    var style = 'ui-state-highlight';
    
    if(type == imi.message_types.error) {
        style = 'ui-state-error';
        $('#imi_messages').dialog({title: 'Error'});
    }
    else{
        $('#imi_messages').dialog({title: 'Information'});
    }
    
    $('#imi_messages').html('<div class=' + style + '>' + text + '</div>');
    $('#imi_messages').dialog('open');
    
};

imi.load_home = function (){
    imi.timer.value = setTimeout('imi.logout()', 600*1000);
    imi.current_section = imi.sections.home;
	alert("hola");
    if(imi.current_rol == imi.roles.guest){
        $('#imi_form_login').html(tpl_form_login);
    }
    $.ajax({
        url: 'home.html', 
        success: function (data){
            $('#imi_content_content').html(data);
        }
        });
}

imi.loading = function(state){
    if(state){
        $('#imi_loading').show();
    }
    else{
        $('#imi_loading').hide();
    }
}

imi.browser = function() {
	$('#project_description').val($('#project_input_file').val());
}

/******************** VALIDATION FUNCTIONS ************************/

imi.validanum = function(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[0-9-.\t]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}

imi.validanumber = function (number){
    var filter=/^[0-9.]+$/;
    if (filter.test(number)){
        return true;
    }
    return false;
}

imi.validaletters = function(letters){
    var filter=/^[A-Za-zàèìòùáéíóú]+$/;
    if (filter.test(letters)){
        return true;
    }
    return false;
}

imi.validal = function(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    patron =/[A-Za-z\s'àèìòùáéíóú\t]/; // 4
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
}

imi.validaEmail = function(e) {
    var filter=/^[A-Za-z][A-Za-z0-9_]*@[A-Za-z0-9_]+\.[A-Za-z0-9_.]+[A-za-z]$/;
    if (filter.test(e)){
        return true;
    }
    return false;
}

imi.valida_form_register = function(){
    var flag = false;
    
    if($('#register_firstname').val() == '' || !imi.validaletters($('#register_firstname').val())){
        $('.imi_input_form #firstname_label').text('field alfanumeric and obligatory');
        flag = true;
    }
    if($('#register_lastname').val() == '' || !imi.validaletters($('#register_lastname').val())){
        $('.imi_input_form #lastname_label').text('field alfanumeric and obligatory');
        flag = true;
    }
    if($('#register_email').val() != '' && !imi.validaEmail($('#register_email').val())){
        $('.imi_input_form #email_label').text('Please enter a valid email');
        flag = true;
    }
    if($('#register_role').val() == ''){
        $('.imi_input_form #username_label').text('field obligatory');
        flag = true;
    }
    if($('#register_password').val() == '' || $('#register_repeat_password').val().length <= 5){
        $('.imi_input_form #password_label').text('password so short or empty');
        flag = true;
    }
    if($('#register_repeat_password').val() == '' || $('#register_repeat_password').val().length <= 5){
        $('.imi_input_form #rpassword_label').text('password so short or empty');
        flag = true;
    }
    return flag;
}

imi.clean_register = function(){
    
    if($('#register_firstname').val() != '' && imi.validaletters($('#register_firstname').val())){
        $('.imi_input_form #firstname_label').text('*');
    }
    if($('#register_lastname').val() != '' && imi.validaletters($('#register_lastname').val())){
        $('.imi_input_form #lastname_label').text('*');
    }
    if(imi.validaEmail($('#register_email').val())){
        $('.imi_input_form #email_label').text('');
    }
    if($('#register_role').val() != ''){
        $('.imi_input_form #username_label').text('*');
    }
    if($('#register_password').val() != '' && $('#register_repeat_password').val().length >= 5){
        $('.imi_input_form #password_label').text('*');
    }
    if($('#register_repeat_password').val() != '' && $('#register_repeat_password').val().length >= 5){
        $('.imi_input_form #rpassword_label').text('*');
    }
    
}

imi.valida_form_project = function(){
    var flag = false;
    
    if($('#project_title').val() == ''){
        $('.imi_input_form #project_title_label').text('field is obligatory');
        flag = true;
    }
    return flag;
}

imi.clean_project = function(){
    
    if($('#project_title').val() != ''){
        $('.imi_input_form #project_title_label').text('*');
    }
    if($('#project_description').val() != ''){
        $('.imi_input_form #project_y_label').text('*');
    }
    
}


/***************************** TEMPLATES **************************************/
var tpl_form_login = '<dl><dd><span>Username: </span><input class="ui-widget input ui-corner-all" type="text" id="login_username"></dd>';
tpl_form_login += '<dd><span>Password: </span><input class="ui-widget input ui-corner-all" type="password" id="login_password" style="weight:15px;">';
tpl_form_login += '<button class="ui-button ui-button-text-only ui-widget ui-state-default ui-corner-all" onclick="imi.authentication()">';
tpl_form_login += '<span class="ui-button-text">Go</span></button></dd>';
tpl_form_login += '<dd><span class="ui-button-text"><a href="javascript:;" onclick="imi.open_form_register()" class="ui-button-text imi_login">Do you want to register?</a></span></dd></dl>';

var tpl_traffic_segment = function(segment_obj){
    var html ='<div class="ui-corner-tr imi_projects_projects" id="imi_static_block_project_'+segment_obj.id+'">';
    html += '<div class="ui-widget-header"></div><div>';
    html += '<div><span class = "imi_static_block_label">Coord X: </span><span>'+segment_obj.x+'</span></div>';
    html += '<div><span class = "imi_static_block_label">Coord Y: </span><span>'+segment_obj.y+'</span></div>';
    html += '<div><span class = "imi_static_block_label">Description: </div>';
    html += '<div class="imi_project_description">'+segment_obj.description+'</div>';
    html += '<div class="imi_project_description_button">... <span class="ui-button ui-state-default ui-corner-all" onclick="imi.load_project_description('+segment_obj.id+');"><span class="ui-icon ui-icon-comment"></span></span></div></div>';
    if(imi.current_section == imi.sections.projects){
        html += '<div class="imi_project_buttons"><span class="ui-button ui-state-default ui-corner-all" onclick="imi.delete_project_confirm('+segment_obj.id+');"><span class="ui-icon ui-icon-trash"></span></span></div>';
    }
    html += '</div>';
    return html;
};

var tpl_project_project = function(project_obj){
    var html = '<div class="ui-corner-tr segments" id="imi_static_block_project">';
    html += '<div class="ui-widget-header">'+project_obj.title+'</div><div>';
    html += '<div><span class = "imi_static_block_label">Coordinator: </span><span>'+project_obj.coordinator+'</span></div>';
    html += '<div><span class = "imi_static_block_label">State: </span><span>'+project_obj.state+'</span></div>';
	html += '<div><span class = "imi_static_block_label">Description: </span><span><span class="ui-button-text"><a href="javascript:;" onclick="imi.open_description_project('+project_obj.description+')" class="ui-button-text imi_description">Open</a></span></span></div>';
    html += '<div><span class = "imi_static_block_label">Participant 1: </span><span>'+project_obj.participant1+'</span></div>';
    html += '<div><span class = "imi_static_block_label">Participant 2: </span><span>'+project_obj.participant2+'</span></div>';
	html += '<div><span class = "imi_static_block_label">Participant 3: </span><span>'+project_obj.participant3+'</span></div>';
    //html += '<div class="imi_segment_intesity"><span class = "imi_static_block_label">Intensity: </span><span id="imi_segment_intensity_'+project_obj.id+'">'+project_obj.intensity+'</span>';
    if(imi.current_rol == imi.roles.coordinator){
        html += '<div class="imi_traffic_edition_button">';
        html += '<span class="ui-button ui-state-default ui-corner-all" onclick="imi.update_intensity('+project_obj.id+');"><span class="ui-icon ui-icon-document"></span></span></div>';
    }
	if(imi.current_rol == imi.roles.participant){
        html += '<div class="imi_traffic_edition_button">';
        html += '<span class="ui-button ui-state-default ui-corner-all" onclick="imi.update_intensity('+project_obj.id+');"><span class="ui-icon ui-icon-check"></span></span></div>';
    }
	if(imi.current_rol == imi.roles.admin){
        html += '<div class="imi_project_buttons"><span class="ui-button ui-state-default ui-corner-all" onclick="imi.delete_project_confirm('+project_obj.id+');"><span class="ui-icon ui-icon-trash"></span></span></div>';
    }
    html += '</div></div></div>';
    
    return html;
};

var tpl_project_insert = function(insert_mode){
    var tpl_project_section =  '<div class="imi_static_Block"  id="imi_content_project">';
    if(insert_mode){
            tpl_project_section +=  '<a href="javascript:;" onclick="imi.open_form_project()" id="demo-link"><span class="ui-button ui-corner-all"><span class="ui-icon ui-icon-newwin"></span></span>New Project</a>';
    }
    tpl_project_section +=  '<div class="imi_static_block_title"><span><h3> Projects <h3></span></div><div id="imi_content_project_list"></div></div>';
    return tpl_project_section;
};

var tpl_segment_section = '<div class="imi_static_block_title"><span> <h3>Segments</h3> </span></div>'+
    '<div id="imi_content_segments_list"></div>';

var tpl_traffic_section = '<div class="imi_static_Block"  id="imi_content_traffic">' + 
    '<span>Coordinate X: </span><input class="ui-widget input ui-corner-all" type="text" id="traffic_form_x" size="1" onKeyPress="return imi.validanum(event)" />' +
    '<span>Coordinate Y: </span><input class="ui-widget input ui-corner-all" type="text" id="traffic_form_y" size="1" onKeyPress="return imi.validanum(event)" />' +
    '<span>Limit: </span><input class="ui-widget input ui-corner-all" type="text" id="traffic_form_limit" size="1" onKeyPress="return imi.validanum(event)" />' +
    '<span class="ui-button ui-state-default ui-corner-all" onclick="imi.search();"><span class="ui-icon ui-icon-search"></span></span><div id="imi_segments_box"></div><div id="imi_projects_box"></div></div>';