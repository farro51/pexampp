<?php

/*
 *  This file is part of Restos software
 * 
 *  Restos is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  Restos is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Restos.  If not, see <http://www.gnu.org/licenses/>.
 */

Restos::using('drivers.iacpersistenceoperations');

/**
 * Class Driver_acsql
 *
 * @author Cristina Madrigal <malevilema@gmail.com>
 * @version 0.1
 */
class Driver_infomobilita implements iACPersistenceOperations {
    
    /**
     * 
     * Properties of the driver, with application level
     * @var object
     */
    private $_properties;
    
    /**
     * 
     * Object to manage SQL conexions and queries 
     * @var Connector_relationaldb
     */
    private $_connection;
    
    /**
     *
     * Table name prefix
     * @var string
     */
    private $_prefix = '';
    
    /**
     * 
     * ConfigFilePath property is required and the file need exist, if not exist an exception is generated
     * 
     * @param object $properties
     * @throws Exception - ConnectionString is required.
     * @throws Exception - Others in PEAR MDB2.
     */
    public function __construct($properties){
        if(!is_object($properties) || !isset($properties->ConnectionString)){
            throw new Exception('ConnectionString is required.');
        }

        $this->_properties = $properties;
        
        $options = array();
        if (!empty($properties->Options)) {
            $options = (array)$properties->Options;
        }

        if (property_exists($properties, 'Prefix')) {
            $this->_prefix = $properties->Prefix;
        }

        Restos::using('data_handlers.relationaldb.connector_relationaldb');
        $connector = new Connector_relationaldb($properties->ConnectionString, $options);
        
        $this->_connection = $connector;
    }


    /**
     * 
     * Return a user entity
     * @param $resource_key User identifier
     * @return object User
     */
    public function getUser($resource_key){

        $prototype = null;

        $sql = 'SELECT * FROM ' . $this->_prefix . 'user WHERE email = ' . $this->_connection->quote($resource_key, 'varchar');

        $row = $this->_connection->getRow($sql);
        
        
        
        if (is_object($row)) {
            
            $prototype = array();
            $prototype['id']        = $resource_key;
            $prototype['username']  = $row->email;
            $prototype['password']  = $row->password;
        }
        
        return $prototype;
    }
    
    /**
     * 
     * Return a alert entity
     * @param $resource_key alert identifier
     * @return object alert
     */
    public function getAlert($resource_key){

        $prototype = null;

        $sql = 'SELECT * FROM ' . $this->_prefix . 'alert WHERE id = ' . $this->_connection->quote($resource_key, 'integer');

        $row = $this->_connection->getRow($sql);
        
        if (is_object($row)) {
            
            $prototype = array();
            $prototype['id']                = $resource_key;
            $prototype['x']                 = $row->x;
            $prototype['y']                 = $row->y;
            $prototype['description']       = $row->description;
        }
        
        return $prototype;
    }
    
    /**
     * 
     * Return an array of alert entity
     * @param $username user identifier
     * @return array alert
     */
    public function getAlerts(){
        
        if(empty($_SESSION['imi.users'])){
            return null;
        }
        
        $prototype = null;
        
        if($_SESSION['imi.users']->rol == 'user'){
            $sql = 'SELECT * FROM ' . $this->_prefix . 'alert where userid = ' . $this->_connection->quote($_SESSION['imi.users']->id, 'integer');
        }
        else{
            $sql = 'SELECT * FROM ' . $this->_prefix . 'alert ';
        }

        $alerts = $this->_connection->getList($sql);
        $restalerts = array();
        
        foreach ($alerts as $alert) {
            $prototype = array();
            $prototype['id']                = $alert->id;
            $prototype['x']                 = $alert->x;
            $prototype['y']                 = $alert->y;
            $prototype['description']       = $alert->description;
            
            $restalerts[] = $prototype;
        }
        
        return $restalerts;
    }
    
    /**
     * 
     * Return an array of alert entity
     * @return array alert
     */
    public function searchAlerts($x, $y, $limit){
        $prototype = null;
        $x = $this->_connection->quote($x, 'integer');
        $y = $this->_connection->quote($y, 'integer');
        $limit = $this->_connection->quote($limit, 'integer');
        $sql = "SELECT * FROM {$this->_prefix}alert WHERE POW((POW((x - $x),2) + POW((y - $y),2)),0.5) <= $limit";
        $alerts = $this->_connection->getList($sql);
        $restalerts = array();
        
        foreach ($alerts as $alert) {
            $prototype = array();
            $prototype['id']                = $alert->id;
            $prototype['x']                 = $alert->x;
            $prototype['y']                 = $alert->y;
            $prototype['description']       = $alert->description;
            
            $restalerts[] = $prototype;
        }
        
        return $restalerts;
    }
    
    /**
     * 
     * Return an array of segment entity
     * @return array segment
     */
    public function searchSegments($x, $y, $limit){
        $prototype = null;
        $x = $this->_connection->quote($x, 'integer');
        $y = $this->_connection->quote($y, 'integer');
        $limit = $this->_connection->quote($limit, 'integer');
        $sql = "SELECT * FROM {$this->_prefix}segment WHERE POW((POW((x1 - $x),2) + POW((y1 - $y),2)),0.5) <= $limit OR POW((POW((x2 - $x),2) + POW((y2 - $y),2)),0.5) <= $limit";
        $alerts = $this->_connection->getList($sql);
        $restalerts = array();
        
        foreach ($alerts as $segment) {
            $prototype = array();
            $prototype['id']                = $segment->id;
            $prototype['nome']                = $segment->nome;
            $prototype['x1']                 = $segment->x1;
            $prototype['y1']                 = $segment->y1;
            $prototype['x2']                 = $segment->x2;
            $prototype['y2']                 = $segment->y2;
            $prototype['intensity']       = $segment->intensity;
            
            $restalerts[] = $prototype;
        }
        
        return $restalerts;
    }
    
    /**
     * 
     * Return an array of project entity
     * @return array project
     */
	 public function getProjects(){
    
        if(empty($_SESSION['imi.users'])){
            return null;
        }
        
        $prototype = null;
        
        if($_SESSION['imi.users']->rol == 'admin' || $_SESSION['imi.users']->rol == 'participant' || $_SESSION['imi.users']->rol == 'guest'){
            $sql = 'SELECT a.id, title, description, state, b.name, b.lastname, a.participant1, a.participant2, a.participant3  FROM ' . $this->_prefix . 'project a, user b WHERE a.coordinator=b.id ';
        }
		else if($_SESSION['imi.users']->rol == 'coordinator'){

            $sql = 'SELECT a.id, title, description, state, b.name, b.lastname, a.participant1, a.participant2, a.participant3  FROM ' . $this->_prefix . 'project a, user b WHERE a.coordinator=b.id AND b.id= ' . $this->_connection->quote($_SESSION['imi.users']->id, 'integer');
        }
        else{
            return false;
        }

        $projects = $this->_connection->getList($sql);
		
		$restprojects = array();
        
        foreach ($projects as $project) {
			
			$prototype = array();
            $prototype['id']                = $project->id;
            $prototype['title']             = $project->title;
            $prototype['coordinator']       = $project->name.' '.$project->lastname;
            $prototype['state']             = $project->state;
            $prototype['description']       = $project->description;
			
			if(!empty($project->participant1)){
				$sql = 'SELECT name, lastname FROM '.$this->_prefix.'user WHERE id= '.$project->participant1;
				$participant = $this->_connection->getRow($sql);
				if($participant){
					$prototype['participant1'] = $participant->name.' '.$participant->lastname;
				}
			}
			else{
				$prototype['participant1'] = 'unallocated';
			}
			
			if(!empty($project->participant2)){
				$sql = 'SELECT name, lastname FROM '.$this->_prefix.'user WHERE id= '.$project->participant2;
				$participant = $this->_connection->getRow($sql);
				if($participant){
					$prototype['participant2'] = $participant->name.' '.$participant->lastname;
				}
			}
			else{
				$prototype['participant2'] = 'unallocated';
			}
			
			if(!empty($project->participant3)){
				$sql = 'SELECT name, lastname FROM '.$this->_prefix.'user WHERE id= '.$project->participant3;
				$participant = $this->_connection->getRow($sql);
				if($participant){
					$prototype['participant3'] = $participant->name.' '.$participant->lastname;
				}
			}
			else{
				$prototype['participant3'] = 'unallocated';
			}
            
            $restsegments[] = $prototype;
        }
        
        return $restsegments;
    }
	 
    public function getSegments(){
    
        if(empty($_SESSION['imi.users'])){
            return null;
        }
        
        $prototype = null;
        
        if($_SESSION['imi.users']->rol == 'admin'){
            $sql = 'SELECT * FROM ' . $this->_prefix . 'segment ';
        }
        else{
            return false;
        }

        $segments = $this->_connection->getList($sql);
        $restsegments = array();
        
        foreach ($segments as $segment) {
            $prototype = array();
            $prototype['id']                = $segment->id;
            $prototype['x1']                = $segment->x1;
            $prototype['y1']                = $segment->y1;
            $prototype['x2']                = $segment->x2;
            $prototype['y2']                = $segment->y2;
            $prototype['intensity']         = $segment->intensity;
            $prototype['nome']              = $segment->nome;
            
            $restsegments[] = $prototype;
        }
        
        return $restsegments;
    }
    
    /**
     * 
     * Insert an project
     * @return mixed project identifier if alert is inserted; false otherwise
     */
    public function insertProject($title, $description){
        $result = false;
        if(!empty($_SESSION['imi.users']) && property_exists($_SESSION['imi.users'],'rol')){
            if($_SESSION['imi.users']->rol == 'coordinator'){
                $fields = array('title'=>$title, 'description'=>$description, 'coordinator'=>$_SESSION['imi.users']->id, 'participant1'=>null, 'participant2'=>null,'participant3'=>null, 'state'=>'open');
                $result = $this->_connection->insert_record($this->_prefix.'project',$fields, true);
            }
        }
        return $result;
    }
    
    /**
     * 
     * Insert an user
     * @return mixed user identifier if user is inserted; false otherwise
     */
    public function insertUser($name, $lastname, $email, $password, $role){
        $result = false;
        
        $name = $this->_connection->quote($name, 'varchar');
        $lastname = $this->_connection->quote($lastname, 'varchar');
        $email = $this->_connection->quote($email, 'varchar');
        //$password = MD5($password);
        
        $fields = array('name'=>$name, 'lastname'=>$lastname, 'email'=>$email, 'password'=>$password, 'role'=>$role);
        $result = $this->_connection->insert_record($this->_prefix.'user',$fields, true);
        return $result;
    }
    
    /**
     * 
     * Delete an alert
     * @param $resource_key alert identifier
     * @return bool true if alert is deleted; false otherwise
     */
    public function deleteAlert($resource_key){
        $result = false;
        $where = array('id'=>$resource_key);
        if(!empty($_SESSION['imi.users']) && property_exists($_SESSION['imi.users'],'rol')){
            if($_SESSION['imi.users']->rol != 'admin'){
                $where['userid'] = $_SESSION['imi.users']->id;
            }
            $result = $this->_connection->delete_record($this->_prefix.'alert',$where);
        }
        
        return $result;
    }
    
    /**
     * 
     * Delete an alert
     * @param $resource_key alert identifier
     * @return bool true if alert is deleted; false otherwise
     */
    public function updateSegment($resource_key, $intensity){
        $result = false;
        
        if(!empty($_SESSION['imi.users']) && property_exists($_SESSION['imi.users'],'rol')){
            if($_SESSION['imi.users']->rol == 'admin'){
                $intensity = $this->_connection->quote($intensity, 'integer');
                $fields = array('intensity'=>$intensity);
                $where = array('id'=>$resource_key);
                $result = $this->_connection->update_record($this->_prefix.'segment', $fields, $where);
            }
        }
        
        return $result;
    }
    
    /**
     * 
     * Return an user entity object
     * @param $username user identifier
     * @param $password password user
     * @return object
     */
    public function login($username, $password){
        $pass = $password;
        $sql = "SELECT id, role AS rol, CONCAT(name, ' ',lastname) AS fullname FROM " . $this->_prefix . "user where email = " . $this->_connection->quote($username, 'varchar')." AND password = " . $this->_connection->quote($pass, 'varchar');
        $user = $this->_connection->getRow($sql);
        
        if($user){
            $_SESSION['imi.users'] = $user;
            $_SESSION['imi.timer'] = time();
        }
        else{
            $_SESSION['imi.users'] = null;
        }
        
        return $user;
    }
    
    /**
     * 
     * Return an user entity object
     * @param $username user identifier
     * @param $password password user
     * @return object
     */
    public function logout(){
        $_SESSION['imi.users'] = null;
        
        return true;
    }
    
    /**
     * 
     * Return an user entity object
     * @param $username user identifier
     * @param $password password user
     * @return object
     */
    public function currentUser(){
        
        if(!empty($_SESSION['imi.users'])){
            return $_SESSION['imi.users'];
        }
        
        return null;
    }
    
}
