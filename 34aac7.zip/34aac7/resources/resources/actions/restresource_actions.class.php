<?php
/*
 *  This file is part of Restos software
 * 
 *  Restos is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  Restos is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Restos.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Class to manage the users resources
 *
 * @author Cristina Madrigal <malevilema@gmail.com>
 * @version 0.1
 */
class RestResource_Actions extends RestResource {
    
    public function __construct($rest_generic) {
        
        parent::__construct($rest_generic);

        $data = $rest_generic->getDriverData("ACDefault");

        if($data != null) {
            $this->_queryDriver = DriverManager::getDriver($data->Name, $data->Properties);
        }
    }
    
    /**
     * When request verb is post
     * @see resources/RestResource::onPost()
     * @return bool
     */
    public function onPost(){

        $resources = $this->_restGeneric->RestReceive->getResources();
        $parameters = $this->_restGeneric->RestReceive->getParameters();
        $actions = null;
        if ($resources->isSpecificResources()){
            switch($resources->getResourceId()){
                case 'login':
                    if(empty($parameters['username']) || empty($parameters['password'])){
                        //$this->_restGeneric->RestResponse->Content = RestosLang::get('actions.post.usernameandpasswordrequired');
                        return true;
                    }
                    $user = $this->_queryDriver->login($parameters['username'], $parameters['password']);
                    if(!$user){
                        $this->_restGeneric->RestResponse->Content = RestosLang::get('actions.post.usernameorpasswordnovalid');
                        return true;
                    }
                    else{
                        $actions = new stdClass();
                        $actions->successful = true;
                        $actions->entity = $user;
                        
                    }
                    break;
                case 'logout':
                    $response = $this->_queryDriver->logout();
                    if($response){
                        $actions = new stdClass();
                        $actions->successful = true;
                    }
                    else{
                        $actions = RestosLang::get('actions.post.notlogout');
                    }
                    break;
                case 'currentuser':
                    $user = $this->_queryDriver->currentUser();
                    if(!$user){
                        $actions = new stdClass();
                    }
                    else{
                        $actions = new stdClass();
                        $actions->successful = true;
                        $actions->entity = $user;
                        
                    }
                    break;
            }
            
        }
        else {
            return false;
        }
        
        if(!$actions) {
            $this->_restGeneric->RestResponse->setHeader(HttpHeaders::$STATUS_CODE, HttpHeaders::getStatusCode('404'));
        }
        else {
		
            $this->_restGeneric->RestResponse->Content = $actions;
        }

        return true;
    }
    
}
